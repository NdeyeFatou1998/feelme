# aja-sdk — SDK Node.js d'AJA

Relie une boutique en ligne à AJA : ses commandes arrivent sur le téléphone du marchand, et les statuts qu'il change reviennent à la boutique.

## Installation

```bash
npm install aja-sdk
```

Node.js 18 ou plus. Aucune dépendance.

## La clé

Le marchand crée la clé de sa boutique dans son espace AJA, page **Boutiques**. Gardez-la côté serveur, dans une variable d'environnement : jamais dans le navigateur, jamais dans un dépôt.

```js
import { Client } from "aja-sdk";

const aja = new Client({ apiKey: process.env.AJA_KEY });
```

## Envoyer une commande

Juste après l'enregistrement de la commande chez vous. Une panne d'AJA ne doit jamais bloquer la vente.

```js
import { AjaError, OrderInput } from "aja-sdk";

try {
  await aja.orders.create(
    new OrderInput({
      externalId: String(order.id),
      status: "pending",
      allowedNext: ["processing", "cancelled"],
      paymentStatus: "paid",
      paymentMode: "wave",
      total: 44500,
      currency: "XOF",
      customer: { name: "Khadija Ndiaye", phone: "+221770001122" },
      lines: [{ name: "Ensemble bazin riche", quantity: 1, unit_price: 42000 }],
    }),
  );
} catch (error) {
  if (!(error instanceof AjaError)) throw error;
  console.error("AJA", error.message);
}
```

## Appliquer les décisions du marchand

Chaque minute, avec une tâche planifiée :

```bash
* * * * * node /var/www/aja-poll.mjs
```

```js
import { AjaError, COMMAND_TYPE_ORDER_TRANSITION } from "aja-sdk";

for (const command of await aja.commands.pending()) {
  if (command.type !== COMMAND_TYPE_ORDER_TRANSITION) {
    await aja.commands.ack(command.id, false, undefined, [], "unsupported_type");
    continue;
  }
  const status = command.targetStatus();
  try {
    await applyStatus(command.externalId, status);
    await aja.commands.ack(command.id, true, status, await nextStatuses(command.externalId));
  } catch (error) {
    if (error instanceof AjaError) throw error;
    await aja.commands.ack(command.id, false, undefined, [], String(error.message));
  }
}
```

## Documentation

Le guide complet (profil de la boutique, catalogue, montants, erreurs, mise en service) est dans votre espace marchand AJA :
https://www.ajaflow.com/app/documentation

## Licence

MIT
